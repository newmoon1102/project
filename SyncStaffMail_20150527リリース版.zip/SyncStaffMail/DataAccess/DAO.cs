﻿using Commons;
using Commons.Helpers;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class DAO
    {
        public static SqlDataReader GetAddressListReader(int ml_cd)
        {           
            SqlConnection conn = new SqlConnection(AppConfig.ConnectionString);
            string sql = Define.SQL_SELECT_ADDRESS_LIST + ml_cd;
            conn.Close();
            return SQLHelper.ReadData(sql, conn);
        }

        public static SqlDataReader GetMLListReader()
        {
            SqlConnection conn = new SqlConnection(AppConfig.ConnectionString);
            string sql = Define.SQL_SELECT_ML_LIST;
            conn.Close();
            return SQLHelper.ReadData(sql, conn);
        }

    }
}
