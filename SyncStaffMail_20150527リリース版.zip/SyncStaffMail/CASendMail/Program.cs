﻿using DataAccess;
using Commons;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Text.RegularExpressions;


namespace SyncStaffMail
{
    class Program
    {
        //static string nameFolder = "calendar"; // name folder on server
        
        static string ftpUrl = "ftp://www.634-jp.com/fml/spool/ml"; // url ftp server
        static string ftpUsername = "musashi-hp"; // username ftp server
        static string ftpPassword = "634634"; // password ftp server

        //static string ftpUrl = "ftp://oa-center.sakura.ne.jp/fml/spool/ml"; // url ftp server
        //static string ftpUsername = "oa-center"; // username ftp server
        //static string ftpPassword = ""; // password ftp server
        
        static string fileName1 = "actives";
        static string fileName2 = "members";

        static void Main(string[] args)
        {
            try
            {
                System.Text.Encoding enc = new System.Text.UTF8Encoding(false);//UTF-8 BOM無し

                SqlDataReader mlListReader = DAO.GetMLListReader();
                if (mlListReader != null)
                {
                    while (mlListReader.Read())
                    {
                        int ml_cd = (int)mlListReader[Define.COLUMN_ML_CD];
                        string ml_account = (string)mlListReader[Define.COLUMN_ML_ADDRESS_ACCOUNT];

                        if (ml_account == null || ml_account.Equals("") || ml_account.Equals("bbsreport") || ml_account.Equals("etc") || ml_account.Equals("seishain-ml") || ml_account.Equals("ec"))
                        {
                            continue;
                        }
                        
                        string addressListString = getAddressListString(ml_cd);
                        if (addressListString == null)
                        {
                            continue;
                        } 
                        Console.Write(addressListString);

                        if (!File.Exists(Path.GetFullPath(ml_account)))
                        {
                            Directory.CreateDirectory(Path.GetFullPath(ml_account));//ml_accountに不正な名前がある場合ここでException発生し、終了します。
                        }

                        // check upload file1 flag
                        if (checkUpload(Path.GetFullPath(ml_account + "/" + fileName1), addressListString))
                        {
                            // Write new data to file1.
                            File.WriteAllText(Path.GetFullPath(ml_account + "/" + fileName1), addressListString, enc);
                            //upload new file to server
                            UploadFileToServer.uploadFile(Path.GetFullPath(ml_account + "/" + fileName1), ml_account, ftpUrl, ftpUsername, ftpPassword);
                            //TODO ここでエラー処理
                        }
                        // check upload file2 flag
                        if (checkUpload(Path.GetFullPath(ml_account + "/" + fileName2), addressListString))
                        {
                            // Write new data to file2.
                            File.WriteAllText(Path.GetFullPath(ml_account + "/" + fileName2), addressListString, enc);
                            //upload new file to server
                            UploadFileToServer.uploadFile(Path.GetFullPath(ml_account + "/" + fileName2), ml_account, ftpUrl, ftpUsername, ftpPassword);
                            //TODO ここでエラー処理
                        }

                    }
                    mlListReader.Close();
                }
            }
            catch (Exception ex)
            {
                // create file failed
                Console.WriteLine("Error: " + ex.StackTrace);
            }
        }

        private static string getAddressListString(int ml_cd)
        {
            SqlDataReader reader = DAO.GetAddressListReader(ml_cd);
            string pc_email = "";
            string ktai_email = "";
            if (reader != null)
            {
                string address_list = "";
                while (reader.Read())
                {
                    pc_email = reader[Define.COLUMN_PC_MAIL].ToString();
                    ktai_email = reader[Define.COLUMN_KTAI_MAIL].ToString();

                    Regex regex = new Regex(@"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
                    Match match1 = regex.Match(pc_email);
                    Match match2 = regex.Match(ktai_email);

                    if (match1.Success)
                    {
                        address_list += pc_email + "\n";
                    }
                    if (match2.Success)
                    {
                        address_list += ktai_email + "\n";
                    }
                }
                reader.Close();
                return address_list;
            }
            return null;
        }

        private static bool checkUpload(string fullPath, string addressListString)
        {
            return true;//TODO 実装
            // Read the file as one string.
            if (!File.Exists(fullPath))
            {
                return true;
            }
            else
            {
                // Check data change?
                string text = System.IO.File.ReadAllText(fullPath);
                return (String.Compare(text, addressListString, true) != 0);
            }
        }
    }
}
