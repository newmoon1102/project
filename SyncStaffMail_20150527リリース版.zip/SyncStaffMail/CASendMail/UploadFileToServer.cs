﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Commons
{
    public class UploadFileToServer
    {
        public static void uploadFile(String filePath, String nameFolder, String ftpUrl, String ftpUsername, String ftpPassword)
        {
            // start upload file to FTP Server
            Console.WriteLine("Start upload file {0} to FTP Server {1}.", filePath, ftpUrl + "/" + nameFolder);

            // check connect internet
            bool resultConnectInternet = checkConnectInternet();
            if (!resultConnectInternet)
            {
                throw new System.Exception("No connect internet.");
            }

            // check file upload
            // if not exists 
            if (!File.Exists(filePath))
            {
                throw new System.Exception("file to upload not exists.");
            }

                //upload file to server

            // login server
            WebClient webClient = new WebClient();
            webClient.Credentials = new NetworkCredential(ftpUsername, ftpPassword);

            bool uploadCompleted = false;
            int wait = 1000;
            string ftpDest = ftpUrl + "/" + nameFolder;
            int times = 1;
            do
            {
                uploadCompleted = ftpUpFile(filePath, ftpDest, webClient);
                if (!uploadCompleted)
                {
                    if (!checkConnectInternet())
                    {
                        throw new System.Exception("No connect internet.");
                    }
                    Thread.Sleep(wait);// wait 1 second
                    // enable upload again max 5 times

                    if (times > 5)
                    {
                        break;
                    }
                    times++;
                }
            } while (!uploadCompleted);
        }

        // check connect internet
        private static bool checkConnectInternet()
        {
            bool result = System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable();
            return result;
        }

        // transfer files to server
        private static bool ftpUpFile(string filePath, string ftpDest, WebClient webClient)
        {
            try
            {
                //create full uri path
                string address = ftpDest + "/" + Path.GetFileName(filePath);
                //transfer the file to Uri path via the ftp
                webClient.UploadFile(address, filePath);
                Console.WriteLine(address + "," + Path.GetFullPath(filePath));
                return true;
            }
            catch (Exception ex)
            {
                //transfer the file falsed
                Console.WriteLine("Error: " + ex);
                return false;
            }
        }
    }
}
