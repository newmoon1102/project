﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Commons.Helpers
{
    public class SQLHelper
    {

        public static SqlDataReader ReadData(string SqlCommand, SqlConnection conn)
        {
            
            try
            {
                SqlCommand cmd = new SqlCommand(SqlCommand, conn);
                conn.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                return rdr;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                return null;
            }
        }

    }
}
