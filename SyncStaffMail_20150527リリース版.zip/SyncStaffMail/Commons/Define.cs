﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Commons
{
    public class Define
    {
        public const string SQL_SELECT_ML_LIST = "SELECT ML_CD, SUBSTRING(ML_ADDRESS, 0, CHARINDEX('@', ML_ADDRESS)) AS ML_ADDRESS_ACCOUNT FROM T_0900_007";
        public const string COLUMN_PC_MAIL = "PC_MAIL_ADDRESS";
        public const string COLUMN_KTAI_MAIL = "KTAI_MAIL_ADDRESS";

        public const string SQL_SELECT_ADDRESS_LIST = "SELECT"
+ " (CASE WHEN [T_0900_008].[PC_FLG]='TRUE' THEN [T_0900_002].[PC_MAIL]+'@'+[T_0900_002].[PC_MAIL_DOMAIN] ELSE '' END) AS PC_MAIL_ADDRESS ,"
+ " (CASE WHEN [T_0900_008].[KTAI_FLG]='TRUE' THEN [T_0900_002].[KTAI_MAIL]+'@'+[T_0900_002].[KTAI_MAIL_DOMAIN] ELSE '' END) AS KTAI_MAIL_ADDRESS"
+ " FROM [T_0900_001]"
+ " INNER JOIN [T_0900_002] ON [T_0900_001].[JUGYOIN_CD] = [T_0900_002].[JUGYOIN_CD]"
+ " INNER JOIN [T_0900_008] ON [T_0900_002].[RECORD_KBN] = [T_0900_008].[RECORD_KBN] AND [T_0900_001].[JUGYOIN_CD] = [T_0900_008].[JUGYOIN_CD]"
+ " WHERE [T_0900_002].[RECORD_KBN]=1"
+ " AND ([T_0900_001].[TAISHOKU_FLG] is null or [T_0900_001].[TAISHOKU_FLG] != 'True') AND ([T_0900_001].[KYONENGAPPI_FLG] is null or [T_0900_001].[KYONENGAPPI_FLG] != 'True')"
+ " AND [T_0900_008].[ML_CD]=";
        public const string COLUMN_ML_CD = "ML_CD";
        public const string COLUMN_ML_ADDRESS_ACCOUNT = "ML_ADDRESS_ACCOUNT";


    }
}
